
          document.addEventListener("DOMContentLoaded", () => {
            if (!(window.__mdnPlayJsStarted && window.__mdnPlayJsEnded)) {
              console.warn(
                "[Playground] The JavaScript did not run. This usually means " +
                  "the HTML input contains an unclosed or malformed tag."
              );
            }
          });
        