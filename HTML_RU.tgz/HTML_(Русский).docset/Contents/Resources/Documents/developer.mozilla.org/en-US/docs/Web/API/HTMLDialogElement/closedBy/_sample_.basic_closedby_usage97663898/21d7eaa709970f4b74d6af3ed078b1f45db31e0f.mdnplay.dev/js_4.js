
          const logElement = document.getElementById("log");
function log(text) {
  logElement.innerText = `${logElement.innerText}${text}\n`;
  logElement.scrollTop = logElement.scrollHeight;
}
const button = document.getElementById("open");
button.addEventListener("click", () => {
  const dialog = document.querySelector("dialog");
  dialog.showModal();
});
const dialog = document.querySelector("dialog");
log(`closedBy: ${dialog.closedBy}`);
;
        