
          window.__mdnPlayJsEnded = true;
          try {
            const uuid =
              new URLSearchParams(location.search).get("uuid") || undefined;
            window.parent.postMessage({ uuid, typ: "ready" }, "*");
          } catch (e) {
            console.error("[Playground] Failed to post ready message", e);
          }
        